port = 80
root = "./"
max_size = 8192